<?php

class User_login extends CI_Controller {
    
    
    function index() {
        
        
            $this->load->view("user_registration_view");
        
    }
    
    
    
    
}
